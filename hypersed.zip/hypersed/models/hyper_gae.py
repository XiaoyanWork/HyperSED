import torch
import torch.nn as nn
import torch.nn.functional as F
import scipy.sparse as sp

from geoopt.optim import RiemannianAdam

from hypersed.models.hyper_layers import LorentzGraphConvolution
from hypersed.utils.utils import select_activation, sparse_to_tuple, tensor_to_sparse


class GraphEncoder(nn.Module):
    def __init__(self, manifold, n_layers, in_features, n_hidden, out_dim,
                 dropout, nonlin=None, use_att=False, use_bias=False):
        super(GraphEncoder, self).__init__()
        self.manifold = manifold
        self.layers = nn.ModuleList([])
        self.layers.append(LorentzGraphConvolution(self.manifold, in_features,
                                                   n_hidden, use_bias, dropout=dropout, use_att=use_att, nonlin=None))
        for i in range(n_layers - 2):
            self.layers.append(LorentzGraphConvolution(self.manifold, n_hidden,
                                                       n_hidden, use_bias, dropout=dropout, use_att=use_att, nonlin=nonlin))
        self.layers.append(LorentzGraphConvolution(self.manifold, n_hidden,
                                                       out_dim, use_bias, dropout=dropout, use_att=use_att, nonlin=nonlin))

    def forward(self, x, edge_index):
        for layer in self.layers:
            x = layer(x, edge_index)
        return x


class FermiDiracDecoder(nn.Module):
    def __init__(self, 
                 args,
                 manifold):
        super(FermiDiracDecoder, self).__init__()
        
        self.args = args
        self.manifold = manifold
        self.r = self.args.r
        self.t = self.args.t

    def forward(self, x):
        
        N = x.shape[0]
        dist = torch.zeros((N, N), device=x.device)  # 初始化一个 N x N 的结果张量
        
        for i in range(N):
            # 计算第 i 行的所有距离
            dist[i, :] = self.manifold.dist2(x[i].unsqueeze(0), x)

        probs = torch.sigmoid((self.r - dist) / self.t)
        adj_pred = torch.sigmoid(probs)

        return adj_pred


class HyperGraphAutoEncoder(nn.Module):
    def __init__(self, args, device, manifold, n_layers, in_features, n_hidden, out_dim, dropout, nonlin, use_att, use_bias):
        super(HyperGraphAutoEncoder, self).__init__()

        self.args = args
        self.device = device
        self.manifold = manifold
        self.scale = nn.Parameter(torch.tensor([0.999]), requires_grad=True)

        self.encoder = GraphEncoder(self.manifold, n_layers, in_features + 1, n_hidden, out_dim + 1, 
                                    dropout, nonlin, use_att, use_bias)
        self.decoder = FermiDiracDecoder(self.args, self.manifold)
        self.optimizer = RiemannianAdam(self.parameters(), lr=self.args.lr_gae, weight_decay=args.w_decay)


    def forward(self, x, adj):
        x = x.to(self.device)
        adj = adj.to(self.device)
        
        o = torch.zeros_like(x).to(x.device)
        x = torch.cat([o[:, 0:1], x], dim=1)
        x = self.manifold.expmap0(x)
        z = self.encoder(x, adj)
        z = self.normalize(z)
        adj_pred = self.decoder(z)
        
        return adj_pred, z

    
    def loss(self, x, adj):
        x = x.to(self.device)
        # adj = adj.to(self.device)

        adj_pred, z = self.forward(x, adj)

        adj = tensor_to_sparse(adj, (adj.shape[0], adj.shape[1]))
        pos_weight = float(adj.shape[0] * adj.shape[0] - adj.sum()) / adj.sum()
        norm = adj.shape[0] * adj.shape[0] / float(
            (adj.shape[0] * adj.shape[0] - adj.sum()) * 2)
        adj_label = adj + sp.eye(adj.shape[0])
        adj_label = sparse_to_tuple(adj_label)
        adj_label = torch.sparse.FloatTensor(torch.LongTensor(adj_label[0].T),
                                                torch.FloatTensor(adj_label[1]),
                                                torch.Size(adj_label[2]))
        weight_mask = adj_label.to_dense().view(-1) == 1
        weight_tensor = torch.ones(weight_mask.size(0))
        weight_tensor[weight_mask] = pos_weight
        adj_label = adj_label.to(self.device)
        weight_tensor = weight_tensor.to(self.device)
        loss = norm * F.binary_cross_entropy(adj_pred.view(-1), adj_label.to_dense().view(-1), weight=weight_tensor)
        return loss, adj_pred, z
    

    def normalize(self, x):
        x = self.manifold.to_poincare(x)
        x = x.to(self.device)
        x = F.normalize(x, p=2, dim=-1) * self.scale.clamp(1e-2, 0.999)
        x = self.manifold.from_poincare(x)
        return x

