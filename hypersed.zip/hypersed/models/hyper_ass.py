import torch
import math
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from torch_scatter import scatter_sum
from torch_geometric.utils import dropout_edge

from hypersed.models.hyper_layers import LSENetLayer, LorentzGraphConvolution
from hypersed.models.hyper_gae import GraphEncoder
from hypersed.manifold.lorentz import Lorentz
from hypersed.utils.utils import select_activation
from hypersed.utils.decode import construct_tree



class LSENet(nn.Module):
    def __init__(self, args, manifold, n_layers, in_features, hidden_dim_enc, hidden_features, num_nodes, height=3, temperature=0.1,
                 embed_dim=64, dropout=0.5, nonlin='relu', decay_rate=None, max_nums=None, use_att=True, use_bias=True):
        super(LSENet, self).__init__()
        if max_nums is not None:
            assert len(max_nums) == height - 1, "length of max_nums must equal height-1."
        self.args = args
        self.manifold = manifold
        self.nonlin = select_activation(nonlin) if nonlin is not None else None
        self.temperature = temperature
        self.num_nodes = num_nodes
        self.height = height
        self.scale = nn.Parameter(torch.tensor([0.999]), requires_grad=True)
        self.embed_layer = GraphEncoder(self.manifold, n_layers, in_features + 1, hidden_dim_enc, embed_dim + 1, 
                                        use_att=use_att, use_bias=use_bias, dropout=dropout, nonlin=self.nonlin)
        
        self.layers = nn.ModuleList([])
        if max_nums is None:
            decay_rate = int(np.exp(np.log(num_nodes) / height)) if decay_rate is None else decay_rate
            max_nums = [int(num_nodes / (decay_rate ** i)) for i in range(1, height)]
        for i in range(height - 1):
            self.layers.append(LSENetLayer(self.manifold, embed_dim + 1, hidden_features, max_nums[i],
                                           bias=use_bias, use_att=use_att, dropout=dropout,
                                           nonlin=self.nonlin, temperature=self.temperature))

    def forward(self, z, edge_index):

        if not self.args.hgae:
            o = torch.zeros_like(z).to(z.device)
            z = torch.cat([o[:, 0:1], z], dim=1)
            z = self.manifold.expmap0(z)
        z = self.embed_layer(z, edge_index)
        z = self.normalize(z)

        self.tree_node_coords = {self.height: z}
        self.assignments = {}

        edge = edge_index.clone()
        ass = None
        for i, layer in enumerate(self.layers):
            z, edge, ass = layer(z, edge)
            self.tree_node_coords[self.height - i - 1] = z
            self.assignments[self.height - i] = ass

        self.tree_node_coords[0] = self.manifold.Frechet_mean(z)
        self.assignments[1] = torch.ones(ass.shape[-1], 1).to(z.device)

        return self.tree_node_coords, self.assignments

    def normalize(self, x):
        x = self.manifold.to_poincare(x).to(self.scale.device)
        x = F.normalize(x, p=2, dim=-1) * self.scale.clamp(1e-2, 0.999)
        x = self.manifold.from_poincare(x)
        return x