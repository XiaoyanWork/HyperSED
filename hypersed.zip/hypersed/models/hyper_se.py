import torch
import math
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

from geoopt.manifolds import PoincareBall
from geoopt.manifolds.stereographic.math import project, dist0, dist
from torch_scatter import scatter_sum
from torch_geometric.utils import negative_sampling
from geoopt.optim import RiemannianAdam

from hypersed.models.hyper_layers import LorentzGraphConvolution, LorentzLinear
from hypersed.manifold.lorentz import Lorentz
from hypersed.models.hyper_gae import GraphEncoder
from hypersed.models.hyper_ass import LSENet
from hypersed.utils.utils import gumbel_softmax
from hypersed.utils.decode import construct_tree
from hypersed.utils.namedtuples import DSIData

MIN_NORM = 1e-15
EPS = 1e-6


class HyperSE(nn.Module):
    # def __init__(self, args, manifold, n_layers, device, in_features, hidden_features, num_nodes, height=3, temperature=0.2,
    #              embed_dim=2, out_dim = 2, dropout=0.5, nonlin='relu', decay_rate=None, max_nums=None, use_att=True, use_bias=True):
    def __init__(self, args, manifold, n_layers, device, in_features, hidden_dim_enc, hidden_features, num_nodes, height=3, temperature=0.2,
                 embed_dim=2, dropout=0.5, nonlin='relu', decay_rate=None, max_nums=None, use_att=True, use_bias=True):
        
        super(HyperSE, self).__init__()
        self.num_nodes = num_nodes
        self.height = height
        self.tau = temperature
        self.manifold = manifold
        self.device = device
        self.encoder = LSENet(args, self.manifold, n_layers, in_features, hidden_dim_enc, hidden_features,
                              num_nodes, height, temperature, embed_dim, dropout,
                              nonlin, decay_rate, max_nums, use_att, use_bias)
        self.optimizer_pre = RiemannianAdam(self.parameters(), lr=args.lr_pre, weight_decay=args.w_decay)
        self.optimizer = RiemannianAdam(self.parameters(), lr=args.lr, weight_decay=args.w_decay)

    def forward(self, features, adj):
        features = features.to(self.device)
        adj = adj.to(self.device)
        adj = adj.to_dense()
        embeddings, clu_mat = self.encoder(features, adj)
        self.embeddings = {}
        self.num_nodes = features.shape[0]
        for height, x in embeddings.items():
            self.embeddings[height] = x.detach()
        ass_mat = {self.height: torch.eye(self.num_nodes).to(self.device)}
        for k in range(self.height - 1, 0, -1):
            ass_mat[k] = ass_mat[k + 1] @ clu_mat[k + 1]
        for k, v in ass_mat.items():
            idx = v.max(1)[1]
            t = torch.zeros_like(v)
            t[torch.arange(t.shape[0]), idx] = 1.
            ass_mat[k] = t
        self.ass_mat = ass_mat
        return self.embeddings[self.height]

    def loss(self, input_data: DSIData):

        device = input_data.device
        weight = input_data.weight.to(self.device)
        adj = input_data.adj.to(self.device)
        degrees = input_data.degrees.to(self.device)
        features = input_data.feature.to(self.device)
        edge_index = input_data.edge_index.to(self.device)
        neg_edge_index = input_data.neg_edge_index.to(self.device)
        pretrain = input_data.pretrain
        self.num_nodes = features.shape[0]

        embeddings, clu_mat = self.encoder(features, adj.to_dense())

        se_loss = 0
        vol_G = weight.sum()
        ass_mat = {self.height: torch.eye(self.num_nodes).to(self.device)}
        vol_dict = {self.height: degrees, 0: vol_G.unsqueeze(0)}
        for k in range(self.height - 1, 0, -1):
            ass_mat[k] = ass_mat[k + 1] @ clu_mat[k + 1]
            vol_dict[k] = torch.einsum('ij, i->j', ass_mat[k], degrees)

        edges = torch.cat([edge_index, neg_edge_index], dim=-1)
        prob = self.manifold.dist(embeddings[self.height][edges[0]], embeddings[self.height][edges[1]])
        prob = torch.sigmoid((2. - prob) / 1.)
        label = torch.cat([torch.ones(edge_index.shape[-1]), torch.zeros(neg_edge_index.shape[-1])]).to(self.device)
        lp_loss = F.binary_cross_entropy(prob, label)

        if pretrain:
            return self.manifold.dist0(embeddings[0]) + lp_loss

        for k in range(1, self.height + 1):
            vol_parent = torch.einsum('ij, j->i', clu_mat[k], vol_dict[k - 1])  # (N_k, )
            log_vol_ratio_k = torch.log2((vol_dict[k] + EPS) / (vol_parent + EPS))  # (N_k, )
            ass_i = ass_mat[k][edge_index[0]]   # (E, N_k)
            ass_j = ass_mat[k][edge_index[1]]
            weight_sum = torch.einsum('en, e->n', ass_i * ass_j, weight)  # (N_k, )
            delta_vol = vol_dict[k] - weight_sum    # (N_k, )
            se_loss += torch.sum(delta_vol * log_vol_ratio_k)
        se_loss = -1 / vol_G * se_loss
        return se_loss + self.manifold.dist0(embeddings[0]) + lp_loss