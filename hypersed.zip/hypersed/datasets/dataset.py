import os
import pickle
import torch
import numpy as np

from typing import List
from scipy import sparse
from torch_geometric.utils import from_networkx, negative_sampling
from torch_scatter import scatter_sum

from hypersed.utils.namedtuples import SingleBlockData, EdgeIndexTypes, Views
from hypersed.utils.utils import index2adjacency, get_euc_anchors, get_euc_anchors_alladj, get_euc_anchors_alladj_as


def mask_edges(edge_index, neg_edges, val_prop=0.05, test_prop=0.1):
    n = len(edge_index[0])
    n_val = int(val_prop * n)
    n_test = int(test_prop * n)
    edge_val, edge_test, edge_train = edge_index[:, :n_val], edge_index[:, n_val:n_val + n_test], edge_index[:, n_val + n_test:]
    val_edges_neg, test_edges_neg = neg_edges[:, :n_val], neg_edges[:, n_val: n_test + n_val]
    train_edges_neg = torch.cat([neg_edges, val_edges_neg, test_edges_neg], dim=-1)
    if test_prop == 0:
        return (edge_train, edge_val), (train_edges_neg, val_edges_neg)
    else:
        return (edge_train, edge_val, edge_test), (train_edges_neg, val_edges_neg, test_edges_neg)


class TwitterDataSet:
    def __init__(self, args, dataset_name = "Event2012", block=None):

        self.args = args
        self.dataset_name = dataset_name
        if args.mode == 'open_set':
            self.path: str = f"{args.data_path}/data_{args.encode}/{self.dataset_name}/{args.mode}/{block}"
        else:
            self.path: str = f"{args.data_path}/data_{args.encode}/{self.dataset_name}/{args.mode}/"
        self.data = self.get_data(self.path)
        print('Got data.')


    def get_data(self, path):

        with open(path + f"/{self.args.encode}_embeddings.pkl", 'rb') as file:
            feature = pickle.load(file)

        temp = np.load(path + '/' + 'label.npy', allow_pickle=True)
        labels = np.asarray([int(each) for each in temp])
        num_classes = len(np.unique(labels))
        num_features = feature.shape[1]
        num_nodes = feature.shape[0]

        cur_path = f"{path}/message_graph_{self.args.edge_type}.npz"
        matrix = sparse.load_npz(cur_path)
        source_nodes, target_nodes = matrix.nonzero()
        edge_index = torch.tensor([source_nodes, target_nodes], dtype=torch.long)
        weight = torch.tensor(matrix.data, dtype=torch.float)
        degrees = scatter_sum(weight, edge_index[0])
        neg_edge_index = negative_sampling(edge_index)
        adj = index2adjacency(num_nodes, edge_index, weight, is_sparse=True)
        edge_index_type = EdgeIndexTypes(edge_index=edge_index, weight=weight, degrees=degrees, 
                                         neg_edge_index=neg_edge_index, adj=adj)
        
        if self.args.pre_anchor:
            anchor_matrix, anchor_fea, anchor_ass, anchor_labels = get_euc_anchors(feature, adj, self.args.anchor_rate, 
                                                                                   self.args.diag, labels)
            num_anchors = anchor_fea.shape[0]
            anchor_edge_index = torch.nonzero(anchor_matrix, as_tuple=False).t()
            # anchor_edge_index = torch.tensor([anchor_source_nodes, anchor_target_nodes], dtype=torch.long)
            anchor_weight = anchor_matrix[anchor_edge_index[0], anchor_edge_index[1]]
            anchor_degrees = scatter_sum(anchor_weight, anchor_edge_index[0])
            anchor_neg_edge_index = negative_sampling(anchor_edge_index)
            anchor_adj = index2adjacency(num_anchors, anchor_edge_index, anchor_weight, is_sparse=True)
            anchor_edge_index_type = EdgeIndexTypes(edge_index=anchor_edge_index, weight=anchor_weight, 
                                                    degrees=anchor_degrees, neg_edge_index=anchor_neg_edge_index, 
                                                    adj=anchor_adj)
        else:
            num_anchors, anchor_fea, anchor_edge_index_type, anchor_ass, anchor_labels = None, None, None, None, None
        
        return SingleBlockData(feature=feature, num_features=num_features, labels=labels, 
                               num_nodes=num_nodes, num_classes=num_classes, 
                               edge_index_types=edge_index_type, anchor_feature=anchor_fea, num_anchors=num_anchors,
                               anchor_edge_index_types=anchor_edge_index_type, anchor_ass=anchor_ass, anchor_labels=anchor_labels)


    def init_incr_data(self):

        for i in sorted(os.listdir(self.path), key=int):
            if i == '0':
                continue
        # for i in (19,20):    # for test
            self.datas.append(self.get_block_data(os.path.join(self.path, str(i))))