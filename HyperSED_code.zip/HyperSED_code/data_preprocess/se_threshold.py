import networkx as nx
import numpy as np
from itertools import combinations
from SE import SE
from tqdm import tqdm

def compute_argmin(C, all_1dSEs):
    N = len(all_1dSEs)
    min_val = float('inf')
    min_i = None
    
    for j, i in enumerate(C):
        sum_val = 1/N * np.sum(all_1dSEs) - all_1dSEs[j]
        
        if sum_val < min_val:
            min_val = sum_val
            min_i = i
    
    return min_i

def search_threshold(embeddings, start=0.6, end=0.4, step=-0.05):
    all_1dSEs = []
    
    corr_matrix = np.corrcoef(embeddings)
    np.fill_diagonal(corr_matrix, 0)
    
    for i in tqdm(np.arange(start, end, step)):
        threshold = i
        edges = [(s, d, corr_matrix[s, d]) for s, d in np.ndindex(corr_matrix.shape) if corr_matrix[s, d] >= threshold]
        g = nx.Graph()
        g.add_weighted_edges_from(edges)
        seg = SE(g)
        all_1dSEs.append(seg.calc_1dSE())
    
    best_threshold = compute_argmin(np.arange(start, end, step), all_1dSEs)
    print('best threshold:', best_threshold)
    
    return best_threshold

def get_graph_edges(attributes):
    attr_nodes_dict = {}
    for i, l in enumerate(attributes):
        for attr in l:
            if attr not in attr_nodes_dict:
                attr_nodes_dict[attr] = [i] # node indexing starts from 1
            else:
                attr_nodes_dict[attr].append(i)

    for attr in attr_nodes_dict.keys():
        attr_nodes_dict[attr].sort()

    graph_edges = []
    for l in attr_nodes_dict.values():
        graph_edges += list(combinations(l, 2))
    return list(set(graph_edges))

def get_knn_edges(embeddings, best_threshold):
    corr_matrix = np.corrcoef(embeddings)
    np.fill_diagonal(corr_matrix, 0)
    knn_edges = [(s, d, corr_matrix[s, d]) for s, d in np.ndindex(corr_matrix.shape) if corr_matrix[s, d] >= best_threshold]
        
    return list(set(knn_edges))

def get_global_edges(attributes, embeddings, best_threshold, e_a = True, e_s = True):
    graph_edges, knn_edges = [], []
    if e_a == True:
        graph_edges = get_graph_edges(attributes)
    if e_s == True:
        knn_edges = get_knn_edges(embeddings, best_threshold)
    return list(set(knn_edges + graph_edges))
