import os
import pickle
import json
import numpy as np
import pandas as pd
from scipy import sparse
from datetime import datetime
from se_threshold import search_threshold, get_global_edges

def get_best_threshold(path):
    best_threshold_path = path + '/best_threshold.pkl'
    if not os.path.exists(best_threshold_path):
        embeddings_path = path + '/SBERT_embeddings.pkl'
        with open(embeddings_path, 'rb') as f:
            embeddings = pickle.load(f)
        best_threshold = search_threshold(embeddings)
        best_threshold = {'best_thres': best_threshold}
        with open(best_threshold_path, 'wb') as fp:
            pickle.dump(best_threshold, fp)
        print('best threshold is stored.')

    with open(best_threshold_path, 'rb') as f:
        best_threshold = pickle.load(f)
    print('best threshold loaded.')
    return best_threshold

def construct_graph_event2012_open(e_a=True, e_s=True, test_with_one_block = False):
    save_path = f'./data_preprocess/data_SBERT/Event2012/open_set'
    times = []
    times_save_path = './data_preprocess/graph_times/Event2012/'

    if test_with_one_block:
        blocks = [20]
    else:
        blocks = [i+1 for i in range(21)]

    for block in blocks:
        print('\n\n====================================================')
        print('block: ', block)
        time1 = datetime.now().strftime("%H:%M:%S")
        print('graph_construct starting time', datetime.now().strftime("%H:%M:%S"))

        folder = os.path.join(save_path, str(block))

        embeddings_path = folder + '/SBERT_embeddings.pkl'
        with open(embeddings_path, 'rb') as f:
            embeddings = pickle.load(f)
        
        df_np = np.load(f'{folder}/{block}.npy', allow_pickle=True)
        df = pd.DataFrame(data=df_np, columns=["original_index", "event_id", "tweet_id", "text", "user_id", "created_at", "user_loc",\
                "place_type", "place_full_name", "place_country_code", "hashtags", "user_mentions", "image_urls", "entities", 
                "words", "filtered_words", "sampled_words", "date"])

        all_node_features = [[str(u)] + [str(each) for each in um] + [h.lower() for h in hs] + e 
                             for u, um, hs, e in zip(df['user_id'], df['user_mentions'],  df['hashtags'], df['entities'])]
        
        best_threshold = get_best_threshold(folder)
        best_threshold = best_threshold['best_thres']

        global_edges = get_global_edges(all_node_features, embeddings, best_threshold, e_a = e_a, e_s = e_s)

        corr_matrix = np.corrcoef(embeddings)
        np.fill_diagonal(corr_matrix, 0)
        weighted_global_edges = [(edge[0], edge[1], corr_matrix[edge[0], edge[1]]) 
                                 for edge in global_edges if corr_matrix[edge[0], edge[1]] > 0]
        
        edge_types = 'e_as' if e_s and e_a else 'e_s' if e_s else 'e_a' if e_a else None

        time2 = datetime.now().strftime("%H:%M:%S")
        print('graph_construct ending time', datetime.now().strftime("%H:%M:%S"))
        
        num_nodes = embeddings.shape[0]
        adj_matrix = np.zeros((num_nodes, num_nodes))
        for node1, node2, weight in weighted_global_edges:
            adj_matrix[node1, node2] = weight
            adj_matrix[node2, node1] = weight
            
        sparse_adj_matrix = sparse.csr_matrix(adj_matrix)
        sparse.save_npz(f'{save_path}/{block}/message_graph_{edge_types}.npz', sparse_adj_matrix)

        time = {'t1': time1,
                't2': time2}
        times.append(time)
    
    times_json = json.dumps(times, indent=4)
    if not os.path.exists(times_save_path):
        os.makedirs(times_save_path)
    with open(f'{times_save_path}hypersed_open.json', "w") as json_file:
        json_file.write(times_json)

    return

def construct_graph_event2018_open(e_a=True, e_s=True, test_with_one_block = False):
    save_path = f'./data_preprocess/data_SBERT/Event2018/open_set'
    times = []
    times_save_path = './data_preprocess/graph_times/Event2018/'

    if test_with_one_block:
        blocks = [16]
    else:
        blocks = [i+1 for i in range(16)]

    for block in blocks:
        print('\n\n====================================================')
        print('block: ', block)
        time1 = datetime.now().strftime("%H:%M:%S")
        print('graph_construct starting time', datetime.now().strftime("%H:%M:%S"))

        folder = os.path.join(save_path, str(block))

        embeddings_path = folder + '/SBERT_embeddings.pkl'
        with open(embeddings_path, 'rb') as f:
            embeddings = pickle.load(f)
        
        df_np = np.load(f'{folder}/{block}.npy', allow_pickle=True)
        df = pd.DataFrame(data=df_np, columns=["original_index", "tweet_id", "user_name", "text", "time", "event_id", "user_mentions", \
                "hashtags", "urls", "words", "created_at", "filtered_words", "entities", "sampled_words", "date"])

        all_node_features = [[str(u)] + [str(each) for each in um] + [h.lower() for h in hs] + e 
                             for u, um, hs, e in zip(df['user_name'], df['user_mentions'],  df['hashtags'], df['entities'])]
        
        best_threshold = get_best_threshold(folder)
        best_threshold = best_threshold['best_thres']

        global_edges = get_global_edges(all_node_features, embeddings, best_threshold, e_a = e_a, e_s = e_s)

        corr_matrix = np.corrcoef(embeddings)
        np.fill_diagonal(corr_matrix, 0)
        weighted_global_edges = [(edge[0], edge[1], corr_matrix[edge[0], edge[1]]) 
                                 for edge in global_edges if corr_matrix[edge[0], edge[1]] > 0]
        
        edge_types = 'e_as' if e_s and e_a else 'e_s' if e_s else 'e_a' if e_a else None

        time2 = datetime.now().strftime("%H:%M:%S")
        print('graph_construct ending time', datetime.now().strftime("%H:%M:%S"))
        
        num_nodes = embeddings.shape[0]
        adj_matrix = np.zeros((num_nodes, num_nodes))
        for node1, node2, weight in weighted_global_edges:
            adj_matrix[node1, node2] = weight
            adj_matrix[node2, node1] = weight
            
        sparse_adj_matrix = sparse.csr_matrix(adj_matrix)
        sparse.save_npz(f'{save_path}/{block}/message_graph_{edge_types}.npz', sparse_adj_matrix)

        time = {'t1': time1,
                't2': time2}
        times.append(time)
    
    times_json = json.dumps(times, indent=4)
    if not os.path.exists(times_save_path):
        os.makedirs(times_save_path)
    with open(f'{times_save_path}hypersed_open.json', "w") as json_file:
        json_file.write(times_json)

    return

def construct_graph_event2018_closed(e_a=True, e_s=True):
    save_path = f'./data_preprocess/data_SBERT/Event2018/closed_set/'
    times_save_path = './data_preprocess/graph_times/Event2018/'

    print('\n\n====================================================')
    time1 = datetime.now().strftime("%H:%M:%S")
    print('graph_construct starting time', datetime.now().strftime("%H:%M:%S"))

    embeddings_path = save_path + 'SBERT_embeddings.pkl'
    with open(embeddings_path, 'rb') as f:
        embeddings = pickle.load(f)
    
    df_np = np.load(f'{save_path}/test_set.npy', allow_pickle=True)
    df = pd.DataFrame(data=df_np, columns=["tweet_id", "user_name", "text", "time", "event_id", "user_mentions", \
            "hashtags", "urls", "words", "created_at", "filtered_words", "entities", "sampled_words"])

    all_node_features = [[str(u)] + [str(each) for each in um] + [h.lower() for h in hs] + e 
                            for u, um, hs, e in zip(df['user_name'], df['user_mentions'],  df['hashtags'], df['entities'])]
    
    best_threshold = get_best_threshold(save_path)
    best_threshold = best_threshold['best_thres']

    global_edges = get_global_edges(all_node_features, embeddings, best_threshold, e_a = e_a, e_s = e_s)

    corr_matrix = np.corrcoef(embeddings)
    np.fill_diagonal(corr_matrix, 0)
    weighted_global_edges = [(edge[0], edge[1], corr_matrix[edge[0], edge[1]]) 
                                for edge in global_edges if corr_matrix[edge[0], edge[1]] > 0]
    
    edge_types = 'e_as' if e_s and e_a else 'e_s' if e_s else 'e_a' if e_a else None

    time2 = datetime.now().strftime("%H:%M:%S")
    print('graph_construct ending time', datetime.now().strftime("%H:%M:%S"))

    num_nodes = embeddings.shape[0]
    adj_matrix = np.zeros((num_nodes, num_nodes))
    for node1, node2, weight in weighted_global_edges:
        adj_matrix[node1, node2] = weight
        adj_matrix[node2, node1] = weight
        
    sparse_adj_matrix = sparse.csr_matrix(adj_matrix)
    sparse.save_npz(f'{save_path}/message_graph_{edge_types}.npz', sparse_adj_matrix)

    time = {'t1': time1,
            't2': time2}
    
    times_json = json.dumps(time, indent=4)
    if not os.path.exists(times_save_path):
        os.makedirs(times_save_path)
    with open(f'{times_save_path}hypersed_closed.json', "w") as json_file:
        json_file.write(times_json)

    return

def construct_graph_event2012_closed(e_a=True, e_s=True):
    save_path = f'./data_preprocess/data_SBERT/Event2012/closed_set/'
    times_save_path = './data_preprocess/graph_times/Event2012/'

    print('\n\n====================================================')
    time1 = datetime.now().strftime("%H:%M:%S")
    print('graph_construct starting time', datetime.now().strftime("%H:%M:%S"))

    embeddings_path = save_path + 'SBERT_embeddings.pkl'
    with open(embeddings_path, 'rb') as f:
        embeddings = pickle.load(f)
    
    df_np = np.load(f'{save_path}/test_set.npy', allow_pickle=True)
    df = pd.DataFrame(data=df_np, columns=["event_id", "tweet_id", "text", "user_id", "created_at", "user_loc",\
            "place_type", "place_full_name", "place_country_code", "hashtags", "user_mentions", "image_urls", "entities", 
            "words", "filtered_words", "sampled_words"])

    all_node_features = [[str(u)] + [str(each) for each in um] + [h.lower() for h in hs] + e 
                            for u, um, hs, e in zip(df['user_id'], df['user_mentions'],  df['hashtags'], df['entities'])]
    
    best_threshold = get_best_threshold(save_path)
    best_threshold = best_threshold['best_thres']

    global_edges = get_global_edges(all_node_features, embeddings, best_threshold, e_a = e_a, e_s = e_s)

    corr_matrix = np.corrcoef(embeddings)
    np.fill_diagonal(corr_matrix, 0)
    weighted_global_edges = [(edge[0], edge[1], corr_matrix[edge[0], edge[1]]) 
                                for edge in global_edges if corr_matrix[edge[0], edge[1]] > 0]
    
    edge_types = 'e_as' if e_s and e_a else 'e_s' if e_s else 'e_a' if e_a else None

    time2 = datetime.now().strftime("%H:%M:%S")
    print('graph_construct ending time', datetime.now().strftime("%H:%M:%S"))
    
    num_nodes = embeddings.shape[0]
    adj_matrix = np.zeros((num_nodes, num_nodes))
    for node1, node2, weight in weighted_global_edges:
        adj_matrix[node1, node2] = weight
        adj_matrix[node2, node1] = weight
        
    sparse_adj_matrix = sparse.csr_matrix(adj_matrix)
    sparse.save_npz(f'{save_path}/message_graph_{edge_types}.npz', sparse_adj_matrix)

    time = {'t1': time1,
            't2': time2}
    
    times_json = json.dumps(time, indent=4)
    if not os.path.exists(times_save_path):
        os.makedirs(times_save_path)
    with open(f'{times_save_path}hypersed_closed.json', "w") as json_file:
        json_file.write(times_json)

    return


if __name__ == "__main__":
    construct_graph_event2012_open(e_a=True, e_s=True)
    construct_graph_event2012_closed(e_a=True, e_s=True)
    construct_graph_event2018_open(e_a=True, e_s=True)
    construct_graph_event2018_closed(e_a=True, e_s=True)
